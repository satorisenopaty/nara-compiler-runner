package com.nara.app

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.view.ViewGroup
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(-1,-1)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(r.url)
            }
            addJavascriptInterface(Bridge(), "NARA")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/nara/index.html")
    }

    private val loader by lazy {
        WebViewAssetLoader.Builder().build()
    }

    inner class Bridge {
        @JavascriptInterface fun sendToGateway(url: String, message: String, historyJson: String): String {
            Thread {
                try {
                    val body = """{"message":${j(message)},"room":"nara-owner","history":[]}"""
                    val conn = java.net.URL(url.trimEnd('/') + "/api").openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 10000
                    conn.readTimeout = 15000
                    conn.setRequestProperty("Content-Type","application/json")
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val text = conn.inputStream.bufferedReader().use { it.readText() }
                    web.post { web.evaluateJavascript("window.gatewayResult(${j(text)})", null) }
                } catch (e: Exception) {
                    web.post { web.evaluateJavascript("window.gatewayError(${j(e.message ?: "Gateway gagal")})", null) }
                }
            }.start()
            return "SENT"
        }
        private fun j(s:String)= "\"" + s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ") + "\""
    }
}
