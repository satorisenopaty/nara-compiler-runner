# NARA Android MVP 1.3 • SECURE BUILD CONTRACT

Milestone:
NARA → DIMENSIKU Gateway → Build Contract

This version does NOT claim to dispatch GitHub Actions or return an APK automatically.
It prepares a signed-by-hash build request so the server side can later hand it to the
NARA Compiler Runner without putting GitHub credentials in the Android app.

## Contract fields

- requestId: generated client-side UUID
- appName
- packageName
- versionName
- projectSha256
- projectSizeBytes
- projectFileName
- sourceType: html | zip
- requestedArtifact: apk-debug
- room: nara-owner
- createdAt

## Security rules

1. No GitHub token in the APK.
2. The Android app sends metadata and build intent, not repository credentials.
3. SHA-256 identifies the exact source package.
4. Server-side validation must reject malformed package names and mismatched hashes.
5. Runner dispatch belongs on the server side.
6. APK retrieval belongs on the server side after the runner reports success.

## Next real integration

DIMENSIKU Gateway / NARA Relay should accept this contract and return:

ACCEPTED → QUEUED → BUILDING → SUCCESS/FAILED

On SUCCESS it should expose a controlled artifact reference.
