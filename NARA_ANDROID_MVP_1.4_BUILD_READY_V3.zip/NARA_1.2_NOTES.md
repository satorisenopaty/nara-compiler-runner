# NARA Android MVP 1.2

Milestone: DIMENSIKU Bridge.

NARA dapat mengirim perintah dari Android ke endpoint DIMENSIKU Gateway melalui HTTPS.

Tujuan tahap ini:
NARA -> DIMENSIKU Gateway -> orkestrasi.

Keamanan:
- Tidak ada GitHub token di APK.
- Tidak mengubah gateway yang sudah ada.
- URL gateway dapat dikonfigurasi dari UI.
- Koneksi menggunakan HTTPS.

Penting:
V1.2 belum mengklaim dispatch GitHub Actions atau menghasilkan APK dari project yang dikirim lewat bridge.
Runner NARA yang sudah terbukti tetap menjadi backend build terpisah.

Target V1.3:
Secure build job contract: gateway menghasilkan build request terverifikasi, lalu backend/runner mengonsumsi request tersebut dan mengembalikan job status.


## 1.3
Added secure build-contract metadata layer. GitHub credentials remain server-side.
