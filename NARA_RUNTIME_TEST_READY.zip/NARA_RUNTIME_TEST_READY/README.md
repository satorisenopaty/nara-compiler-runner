# NARA Runtime Test

This is a small, real Android smoke-test project for the NARA compiler pipeline.
It is intentionally separate from the earlier architecture-only package.

It validates that GitHub Actions can:
- provision JDK 17 and Android SDK
- run Gradle 8.7
- compile a real Android APK and AAB
- verify the artifacts
- upload the artifacts

The APK is a runtime smoke test, not the full NARA Companion product.
