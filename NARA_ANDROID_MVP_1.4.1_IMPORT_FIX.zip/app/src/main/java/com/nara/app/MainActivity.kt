package com.nara.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.view.ViewGroup
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var projectDir: File? = null
    private val PICK_PROJECT = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.allowFileAccessFromFileURLs = true
            settings.allowUniversalAccessFromFileURLs = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(r.url)
            }
            addJavascriptInterface(Bridge(), "NARA")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/nara/index.html")
    }

    private val loader by lazy { WebViewAssetLoader.Builder().build() }

    inner class Bridge {
        @android.webkit.JavascriptInterface
        fun pickProject() {
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/zip"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/octet-stream"))
                }, PICK_PROJECT)
            }
        }

        @android.webkit.JavascriptInterface
        fun checkProject() {
            val dir = projectDir
            val index = dir?.let { findIndex(it) }
            val text = when {
                dir == null -> "Belum ada project."
                index != null -> "PROJECT OK • index.html ditemukan"
                else -> "CHECK GAGAL • index.html tidak ditemukan"
            }
            web.post { web.evaluateJavascript("window.factoryResult('checkStatus',${j(text)})", null) }
        }

        @android.webkit.JavascriptInterface
        fun prepareBuildContract(name: String, pkg: String) {
            val dir = projectDir
            if (dir == null) {
                web.post { web.evaluateJavascript("window.factoryResult('contractStatus',${j("Import project dulu.")})", null) }
                return
            }
            val request = JSONObject().apply {
                put("app_name", name.trim().ifEmpty { "NARA App" })
                put("package_name", pkg.trim().ifEmpty { "com.nara.app" })
                put("version_name", "1.4.1")
                put("source_dir", dir.absolutePath)
            }
            File(dir, "NARA_BUILD_REQUEST.json").writeText(request.toString(2))
            val text = "BUILD REQUEST READY • NARA_BUILD_REQUEST.json"
            web.post { web.evaluateJavascript("window.factoryResult('contractStatus',${j(text)})", null) }
        }

        @android.webkit.JavascriptInterface
        fun previewProject() {
            val dir = projectDir
            val index = dir?.let { findIndex(it) }
            if (index == null) {
                web.post { web.evaluateJavascript("window.factoryResult('checkStatus',${j("Import project dan CHECK dulu.")})", null) }
                return
            }
            runOnUiThread { web.loadUrl(Uri.fromFile(index).toString()) }
        }

        @android.webkit.JavascriptInterface
        fun sendToGateway(url: String, message: String, historyJson: String): String {
            Thread {
                try {
                    val body = "{\"message\":${j(message)},\"room\":\"nara-owner\",\"history\":[]}"
                    val conn = java.net.URL(url.trimEnd('/') + "/api").openConnection() as java.net.HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 10000
                    conn.readTimeout = 15000
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.doOutput = true
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val text = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                        .bufferedReader().use { it.readText() }
                    web.post { web.evaluateJavascript("window.gatewayResult(${j(text)})", null) }
                } catch (e: Exception) {
                    web.post { web.evaluateJavascript("window.gatewayError(${j(e.message ?: "Gateway gagal")})", null) }
                }
            }.start()
            return "SENT"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_PROJECT || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            val root = File(filesDir, "projects/current")
            root.deleteRecursively()
            root.mkdirs()
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input)
                ZipInputStream(input).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val clean = entry.name.replace('\\', '/')
                        require(!clean.startsWith("/") && !clean.split('/').contains("..")) { "ZIP path tidak aman" }
                        val out = File(root, clean)
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fos -> zis.copyTo(fos) }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            projectDir = root
            val index = findIndex(root)
            val status = if (index != null) "IMPORT BERHASIL • index.html ditemukan" else "IMPORT BERHASIL • index.html belum ditemukan"
            web.evaluateJavascript("window.factoryResult('importStatus',${j(status)})", null)
            web.evaluateJavascript("window.factoryResult('checkStatus',${j("Siap CHECK PROJECT.")})", null)
        } catch (e: Exception) {
            web.evaluateJavascript("window.factoryResult('importStatus',${j("IMPORT GAGAL • ${e.message ?: "error"}")})", null)
        }
    }

    private fun findIndex(root: File): File? {
        val direct = File(root, "index.html")
        if (direct.isFile) return direct
        return root.walkTopDown().firstOrNull { it.isFile && it.name.equals("index.html", true) }
    }

    private fun j(s: String): String = JSONObject.quote(s)
}
