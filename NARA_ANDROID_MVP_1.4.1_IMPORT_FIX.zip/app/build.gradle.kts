plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace = "com.nara.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nara.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 15
        versionName = "1.4.1"
    }
    buildFeatures { buildConfig = true }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation("androidx.webkit:webkit:1.13.0")
    implementation("androidx.core:core-ktx:1.15.0")
}
