# NARA Android MVP 1.4 • FACTORY UI

This milestone turns the Runtime Test screen into the intended Factory flow:
Import HTML/ZIP → Factory Check → Build Contract → Preview.

Important:
- This package is source code, not an APK.
- Cloud GitHub dispatch is intentionally not faked.
- GitHub credentials remain outside the Android application.
- The next milestone is connecting the native bridge to the actual file picker,
  private project storage, SHA-256 hashing, preview loading, and the secure relay.
