plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nara.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nara.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 12
        versionName = "1.2.0"
    }
    buildFeatures { buildConfig = true }
}
dependencies {
    implementation("androidx.webkit:webkit:1.13.0")
    implementation("androidx.core:core-ktx:1.15.0")
}
